package br.poli.sr;

import java.awt.Button;
import java.awt.Event;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Rectangle;

import br.poli.sr.gp.GP;
import br.poli.sr.ui.ChoiceUI;
import br.poli.sr.ui.Dialog;
import br.poli.sr.ui.NumberUI;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
public class SettingsDialog extends Dialog {
	private static final long serialVersionUID = 1L;
	
	private GP gp;
	private Button okButton;
	private Button cancelButton;
	private Label status;

	private void addNumberField(NumberUI numberui, int i, int j) {
		addComponent(new Label(numberui.getLabel(), 2), new Rectangle(i - 143,
				j, 140, 14));
		addComponent(numberui, new Rectangle(i, j, 30, 14));
		addComponent(new Label("(" + numberui.getMin() + " ... "
				+ numberui.getMax() + ")"), new Rectangle(i + 40, j, 50, 14));
	}

	private void addChoiceField(ChoiceUI choiceui, int i, int j) {
		addComponent(new Label(choiceui.getLabel(), 2), new Rectangle(i - 143,
				j, 140, 14));
		addComponent(choiceui, new Rectangle(i, j, 90, 14));
	}

	SettingsDialog(Frame frame, GP gp1) {
		super(frame, new Rectangle(8, 8, 280, 282), "Configura��o GP", true);
		gp = gp1;
		setResizable(false);
		okButton = new Button("OK");
		addComponent(okButton, new Rectangle(5, 236, 50, 14));
		cancelButton = new Button("Cancelar");
		addComponent(cancelButton, new Rectangle(60, 236, 50, 14));
		addNumberField(gp1.populationSize, 140, 3);
		addNumberField(gp1.maxDepthForNewIndividuals, 140, 18);
		addNumberField(gp1.crossoverFraction, 140, 33);
		addNumberField(gp1.fitnessProportionateReproFraction, 140, 48);
		addNumberField(gp1.mutationFraction, 140, 63);
		addNumberField(gp1.maxDepthForIndividualsAfterCrossover, 140, 78);
		addNumberField(gp1.maxDepthForNewSubtreesInMutants, 140, 93);
		addChoiceField(gp1.methodOfGeneration, 140, 108);
		addChoiceField(gp1.methodOfSelection, 140, 123);
		addComponent(new Label(gp1.fitnessCases.getLabel()), new Rectangle(5,
				140, 50, 12));
		addComponent(gp1.fitnessCases, new Rectangle(5, 152, 98, 65));
		addComponent(new Label(gp1.functionSet.getLabel()), new Rectangle(110,
				140, 50, 12));
		addComponent(gp1.functionSet, new Rectangle(110, 152, 80, 65));
		addComponent(new Label(gp1.terminalSet.getLabel()), new Rectangle(195,
				140, 50, 12));
		addComponent(gp1.terminalSet, new Rectangle(195, 152, 80, 65));
		status = new Label();
		addComponent(status, new Rectangle(5, 222, 240, 10));
	}

	public String onApply() {
		String s = super.onApply();
		if (s == null)
			gp.settingsChanged();
		return s;
	}

	public boolean action(Event event, Object obj) {
		if (event.target == okButton) {
			String s = onApply();
			if (s == null)
				status.setText("");
			else
				status.setText(s);
			return true;
		}
		if (event.target == cancelButton) {
			onCancel();
			return true;
		} else {
			return false;
		}
	}
}