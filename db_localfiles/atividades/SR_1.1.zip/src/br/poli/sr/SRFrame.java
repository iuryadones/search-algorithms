package br.poli.sr;
import java.awt.Event;
import java.awt.Frame;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
class SRFrame extends Frame {

	public SRFrame(String s) {
		super(s);
	}

	public boolean handleEvent(Event event) {
		switch (event.id) {
		case 201: // Event.WINDOW_DESTROY
			dispose();
			System.exit(0);
			return true;
		}
		return super.handleEvent(event);
	}
}