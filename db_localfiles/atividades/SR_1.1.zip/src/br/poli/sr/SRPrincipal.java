package br.poli.sr;

import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextArea;
import java.util.Observable;
import java.util.Observer;

import br.poli.sr.gp.GP;
import br.poli.sr.gp.GPMessageBestFound;
import br.poli.sr.gp.GPMessageEvaluatingIndividual;
import br.poli.sr.gp.GPMessageEvaluatingPopulation;
import br.poli.sr.gp.GPMessageFitnessCasesSet;
import br.poli.sr.gp.GPMessageStateChanged;
import br.poli.sr.ui.Dialog;
import br.poli.sr.ui.Histogram;
import br.poli.sr.ui.XYPlot;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
public class SRPrincipal extends Applet implements Observer {
	private static final long serialVersionUID = 1L;
	
	boolean m_fStandAlone;
	Button startButton;
	Button pauseButton;
	Button stopButton;
	Button settingsButton;
	XYPlot plot;
	Histogram histogram;
	TextArea status;
	TextArea results;
	GP gp;
	
	public void SRPrincipal(){
		this.setName("UFRPE - Regress�o simb�lica usando PG");
	}

	public void stop() {
		gp.freeze();
	}

	public void destroy() {
		gp.stop();
	}

	public void update(Observable observable, Object obj) {
		if (obj instanceof GPMessageStateChanged) {
			GPMessageStateChanged gpmessagestatechanged = (GPMessageStateChanged) obj;
			switch (gpmessagestatechanged.newState) {
			case 1: // '\001'
				startButton.enable(false);
				pauseButton.enable(true);
				stopButton.enable(true);
				settingsButton.enable(false);
				plot.setTrace(1, null);
				plot.setTrace(2, null);
				results.setText("");
				histogram.setData(null);
				status.setText("Iniciando...");
				break;

			case 2: // '\002'
				startButton.enable(false);
				pauseButton.enable(true);
				pauseButton.setLabel("Retomar");
				stopButton.enable(true);
				settingsButton.enable(false);
				status.setText("Pausado");
				break;

			case 3: // '\003'
				startButton.enable(false);
				pauseButton.enable(true);
				pauseButton.setLabel("Pausar");
				stopButton.enable(true);
				settingsButton.enable(false);
				status.setText("Retomando...");
				break;

			case 4: // '\004'
				startButton.enable(true);
				pauseButton.enable(false);
				pauseButton.setLabel("Pausar");
				stopButton.enable(false);
				settingsButton.enable(true);
				status.setText("Parado\n" + gpmessagestatechanged.text);
				break;
			}
		}
		if (obj instanceof GPMessageFitnessCasesSet) {
			GPMessageFitnessCasesSet gpmessagefitnesscasesset = (GPMessageFitnessCasesSet) obj;
			plot.setTrace(0, gpmessagefitnesscasesset.data);
		}
		if (obj instanceof GPMessageEvaluatingIndividual) {
			GPMessageEvaluatingIndividual gpmessageevaluatingindividual = (GPMessageEvaluatingIndividual) obj;
			status.setText("Avaliando indiv�duo #"
					+ gpmessageevaluatingindividual.individualNr + "\n"
					+ "da gera��o "
					+ gpmessageevaluatingindividual.generationNr);
			plot.setTrace(1, gpmessageevaluatingindividual.data);
		}
		if (obj instanceof GPMessageBestFound) {
			GPMessageBestFound gpmessagebestfound = (GPMessageBestFound) obj;
			plot.setTrace(2, gpmessagebestfound.data);
			results.setText("O melhor indiv�duo \n"
					+ "foi encontrado na gera��o "
					+ gpmessagebestfound.generation + ".\n"
					+ "O fitness ajustado � " + gpmessagebestfound.fitness
					+ "\n\n" + "Sua fun��o �:\n\n"
					+ gpmessagebestfound.program);
		}
		if (obj instanceof GPMessageEvaluatingPopulation) {
			GPMessageEvaluatingPopulation gpmessageevaluatingpopulation = (GPMessageEvaluatingPopulation) obj;
			plot.setTrace(1, null);
			histogram.setData(gpmessageevaluatingpopulation.fitness);
		}
	}

	public static void main(String args[]) {
		SRFrame approxframe = new SRFrame("UFRPE - Regress�o Simb�lica usando PG");
		SRPrincipal approx = new SRPrincipal();
		approxframe.add("Center", approx);
		approx.m_fStandAlone = true;
		approx.init();
		approx.start();
		approxframe.setPreferredSize(new Dimension(740, 540));
		approxframe.pack();
		approxframe.setVisible(true);
	}

	public SRPrincipal() {
	}

	public void start() {
		gp.thaw();
	}

	public String getAppletInfo() {
		return "Name: Aplicativo original Approx\r\n"
				+ "Autor original: Hans U. Gerber\r\nAdaptado por Danilo Ara�jo -> POLI SR";
	}

	public synchronized boolean action(Event event, Object obj) {
		if (event.target == startButton) {
			startButton.enable(false);
			settingsButton.enable(false);
			gp.start();
			return true;
		}
		if (event.target == pauseButton) {
			pauseButton.enable(false);
			int i = gp.getState();
			switch (i) {
			case 1: // '\001'
			case 3: // '\003'
				gp.suspend();
				break;

			case 2: // '\002'
				gp.resume();
				break;
			}
			return true;
		}
		if (event.target == stopButton) {
			stopButton.enable(false);
			pauseButton.enable(false);
			gp.stop();
			return true;
		}
		if (event.target == settingsButton) {
			settingsButton.enable(false);
			startButton.enable(false);
			SettingsDialog settingsdialog = new SettingsDialog(Dialog
					.findFirstFrame(this), gp);
			settingsdialog.show();
			settingsButton.enable(true);
			startButton.enable(true);
			return true;
		} else {
			return false;
		}
	}

	public void init() {
		Panel panelBotoes = new Panel();
		Panel panelResultado = new Panel();
		Panel panelAprox = new Panel();
		Panel panelCentral = new Panel();
		
		panelResultado.setPreferredSize(new Dimension(350, 400));
		panelAprox.setPreferredSize(new Dimension(350, 400));
		
		
		startButton = new Button("Iniciar");
		panelBotoes.add("Wide", startButton);
		pauseButton = new Button("Pausar");
		panelBotoes.add("Wide", pauseButton);
		stopButton = new Button("Parar");
		panelBotoes.add("Wide", stopButton);
		settingsButton = new Button("Configura��es...");
		panelBotoes.add("Wide", settingsButton);
		
		panelAprox.setLayout(new BorderLayout());
		panelAprox.add("North", new Label("Aproxima��o"));
		plot = new XYPlot();
		panelAprox.add("Center", plot);
		
		panelResultado.setLayout(new BorderLayout());
		panelResultado.add("North", new Label("Resultados"));
		results = new TextArea();
		panelResultado.add("Center", results);
		
		Panel panel4 = new Panel();
		panel4.setLayout(new BorderLayout());
		panel4.add("North", new Label("Status"));
		status = new TextArea();
		panel4.add("Center", status);
		
		Panel panel2 = new Panel();
		panel2.setLayout(new BorderLayout());
		histogram = new Histogram();
		panel2.add("Center", histogram);
		
		panelResultado.add("South", panel2);
		
		panelAprox.add(panel4, BorderLayout.SOUTH);
		
		setLayout(new BorderLayout());
		
		panelCentral.setLayout(new BorderLayout());
		
		panelCentral.add(panelAprox, BorderLayout.EAST);
		panelCentral.add(panelResultado, BorderLayout.WEST);
		
		add(panelBotoes, BorderLayout.NORTH);
		add(panelCentral, BorderLayout.CENTER);


		startButton.enable(false);
		pauseButton.enable(false);
		stopButton.enable(false);
		settingsButton.enable(false);
		gp = new GP();
		gp.addObserver(this);
		startButton.enable(true);
		settingsButton.enable(true);
		gp.init();
	}

}