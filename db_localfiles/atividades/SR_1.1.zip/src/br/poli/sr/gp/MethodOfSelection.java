package br.poli.sr.gp;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
class MethodOfSelection {

	public int getValue() {
		return value;
	}

	public String toString() {
		return text;
	}

	MethodOfSelection(String s, int i) {
		text = s;
		value = i;
	}

	static final int FITNESS_PROPORTIONATE = 0;
	static final int TOURNAMENT = 1;
	private String text;
	private int value;
}