/**
 * 
 */
package br.poli.sr.gp;

/**
 * @author Danilo Ara�jo
 */
public class Sqrt extends Function {

	Sqrt() {
		super.arg = new Program[1];
	}

	String getName() {
		return "sqrt";
	}

	double eval(double d) {
		return Math.sqrt(super.arg[0].eval(d));
	}
}