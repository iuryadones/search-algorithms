package br.poli.sr.gp;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
abstract class Program implements Cloneable {

	public abstract String toString(int i);

	abstract int countNodes();

	abstract int countNodes(Condition condition);

	String indent(int i) {
		String s = new String();
		for (int j = 0; j < i; j++)
			s = s + "  ";

		return s;
	}

	abstract String getName();

	protected abstract Object clone();

	abstract double eval(double d);

	Program() {
	}
}