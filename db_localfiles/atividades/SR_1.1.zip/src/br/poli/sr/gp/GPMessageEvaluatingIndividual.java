package br.poli.sr.gp;

import br.poli.sr.ui.RealPoint;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
public class GPMessageEvaluatingIndividual extends GPMessage {

	GPMessageEvaluatingIndividual(int i, int j, RealPoint arealpoint[]) {
		generationNr = i;
		individualNr = j;
		data = arealpoint;
	}

	public int generationNr;
	public int individualNr;
	public RealPoint data[];
}