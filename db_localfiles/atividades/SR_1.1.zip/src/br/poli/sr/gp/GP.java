package br.poli.sr.gp;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Observable;

import br.poli.sr.ui.ChoiceUI;
import br.poli.sr.ui.NumberUI;
import br.poli.sr.ui.PointsUI;
import br.poli.sr.ui.RealPoint;
import br.poli.sr.ui.SetUI;


/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 *
 */
public class GP extends Observable implements Runnable {

	public NumberUI populationSize;
	public NumberUI maxDepthForNewIndividuals;
	public NumberUI maxDepthForIndividualsAfterCrossover;
	public NumberUI maxDepthForNewSubtreesInMutants;
	public NumberUI crossoverFraction;
	public NumberUI fitnessProportionateReproFraction;
	public NumberUI mutationFraction;
	public ChoiceUI methodOfGeneration;
	public ChoiceUI methodOfSelection;
	public PointsUI fitnessCases;
	public SetUI terminalSet;
	public SetUI functionSet;
	Thread thread;
	Individual population[];
	int currentGeneration;
	Individual bestOfRunIndividual;
	int generationOfBestOfRunIndividual;
	static final int MAX_GENERATIONS = 1000;
	static final int SEED = 12345;
	static br.poli.sr.gp.Random random = new br.poli.sr.gp.Random(12345);
	public static final int IDLE = 0;
	public static final int STARTED = 1;
	public static final int SUSPENDED = 2;
	public static final int RESUMED = 3;
	public static final int STOPPED = 4;
	private int state;
	private int oldState;
	static final Condition isProgram = new IsProgram();
	static final Condition isFunction = new IsFunction();

	void evaluateFitnessOfPopulation() {
		for (int i = 0; i < population.length; i++)
			fitnessFunction(population[i], i);

	}

	public synchronized void stop() {
		if (thread != null && thread.isAlive()) {
			state = 4;
			notifyObservers(new GPMessageStateChanged(state, ""));
			thread.stop();
		}
	}

	public synchronized void crash() {
		if (thread != null && thread.isAlive()) {
			state = 4;
			notifyObservers(new GPMessageStateChanged(state,
					"Falha na execu��o \n" + " na gera��o "
							+ currentGeneration + ".\n"));
			thread.stop();
		}
	}

	public int getState() {
		return state;
	}

	public synchronized void suspend() {
		if (thread != null && thread.isAlive()) {
			state = 2;
			notifyObservers(new GPMessageStateChanged(state, ""));
			thread.suspend();
		}
	}

	boolean terminationPredicate() {
		return currentGeneration >= 1000;
	}

	public void notifyObservers(Object obj) {
		setChanged();
		super.notifyObservers(obj);
	}

	int maxDepthOfTree(Program program) {
		int i = 0;
		if (program instanceof Function) {
			for (int j = 0; j < ((Function) program).arg.length; j++) {
				Program program1 = ((Function) program).arg[j];
				int k = maxDepthOfTree(program1);
				i = Math.max(i, k);
			}

			return 1 + i;
		} else {
			return 0;
		}
	}

	void createArgumentsForFunction(Function function, int i, boolean flag) {
		for (int j = 0; j < function.arg.length; j++)
			function.arg[j] = createIndividualProgram(i, false, flag);

	}

	void breedNewPopulation() {
		double d2 = crossoverFraction.doubleValue()
				+ fitnessProportionateReproFraction.doubleValue()
				+ mutationFraction.doubleValue();
		double d3 = crossoverFraction.doubleValue() / d2;
		double d4 = fitnessProportionateReproFraction.doubleValue() / d2;
		Program aprogram[] = new Program[population.length];
		double d = 0.0D;
		int i = 0;
		aprogram[i] = (Program) bestOfRunIndividual.program.clone();
		for (i++; i < population.length;) {
			double d1 = (double) i / (double) population.length;
			Individual individual = findIndividual();
			if (d1 < d3) {
				Individual individual1 = findIndividual();
				Program aprogram1[] = crossover(individual.program,
						individual1.program);
				aprogram[i] = aprogram1[0];
				if (++i < population.length) {
					aprogram[i] = aprogram1[1];
					i = i++;
				}
			} else if (d1 < d4 + d3) {
				aprogram[i] = (Program) individual.program.clone();
				i++;
			} else {
				aprogram[i] = mutate(individual.program);
				i++;
			}
		}

		for (int j = 0; j < population.length; j++)
			population[j].program = aprogram[j];

	}

	void zeroizeFitnessMeasuresOfPopulation() {
		for (int i = 0; i < population.length; i++) {
			population[i].standardizedFitness = 0.0D;
			population[i].adjustedFitness = 0.0D;
			population[i].normalizedFitness = 0.0D;
			population[i].hits = 0;
		}

	}

	Individual findIndividualUsingTournamentSelection() {
		int i = Math.min(population.length, 7);
		Hashtable hashtable;
		int j;
		for (hashtable = new Hashtable(); hashtable.size() < i; hashtable.put(
				new Integer(j), population[j]))
			j = random.nextInt(population.length);

		Enumeration enumeration = hashtable.elements();
		Individual individual = (Individual) enumeration.nextElement();
		double d = individual.standardizedFitness;
		while (enumeration.hasMoreElements()) {
			Individual individual1 = (Individual) enumeration.nextElement();
			double d1 = individual1.standardizedFitness;
			if (d1 < d) {
				individual = individual1;
				d = d1;
			}
		}
		return individual;
	}

	public GP() {
		populationSize = new NumberUI("Tamanho da popula��o", 100D, 10D, 1000D);
		maxDepthForNewIndividuals = new NumberUI(
				"Profundidade m�x. para novos indiv�duos", 6D, 1.0D, 10D);
		maxDepthForIndividualsAfterCrossover = new NumberUI(
				"Profundidade m�x. depois de crossover", 20D, 5D, 20D);
		maxDepthForNewSubtreesInMutants = new NumberUI(
				"Profundidade m�x. depois de muta��o", 4D, 1.0D, 7D);
		crossoverFraction = new NumberUI("Prob. de crossover", 80D, 1.0D, 100D);
		fitnessProportionateReproFraction = new NumberUI(
				"Prob. de reprodu��o", 0.0D, 0.0D, 100D);
		mutationFraction = new NumberUI("Prob. de muta��o", 20D, 0.0D, 100D);
		fitnessCases = new PointsUI("Fitness cases", makeDefaultFitnessCases());
		ProgramChoice aprogramchoice[] = {
				new ProgramChoice("Constante rand�mica", (new RandomConstant())
						.getClass()),
				new ProgramChoice("Vari�vel x", (new Variable()).getClass()) };
		int ai[] = { 0, 1 };
		terminalSet = new SetUI("Conjunto de terminais", aprogramchoice, ai);
		ProgramChoice aprogramchoice1[] = {
				new ProgramChoice("+ (add)", (new Addition()).getClass()),
				new ProgramChoice("- (sub)", (new Subtraction()).getClass()),
				new ProgramChoice("* (mul)", (new Multiplication()).getClass()),
				new ProgramChoice("/ (div)", (new Division()).getClass()),
				new ProgramChoice("sin", (new Sine()).getClass()),
				new ProgramChoice("cos", (new Cosine()).getClass()),
				new ProgramChoice("tan", (new Tan()).getClass()),
				new ProgramChoice("exp", (new Exp()).getClass()),
				new ProgramChoice("ln", (new Ln()).getClass()),
				new ProgramChoice("^2", (new Sqr()).getClass()),
				new ProgramChoice("sqrt", (new Sqrt()).getClass()) };
		int ai1[] = { 0, 1, 2 };
		functionSet = new SetUI("Conjunto de fun��es", aprogramchoice1, ai1);
		MethodOfGeneration amethodofgeneration[] = {
				new MethodOfGeneration("Grow", 0),
				new MethodOfGeneration("Full", 1),
				new MethodOfGeneration("Ramped half and half", 2) };
		methodOfGeneration = new ChoiceUI("M�todo de gera��o",
				amethodofgeneration, 2);
		MethodOfSelection amethodofselection[] = {
				new MethodOfSelection("Proporcional ao Fitness", 0),
				new MethodOfSelection("Torneio", 1) };
		methodOfSelection = new ChoiceUI("M�todo de sele��o",
				amethodofselection, 1);
	}

	public synchronized void start() {
		thread = new Thread(this);
		thread.setPriority(4);
		thread.start();
		state = 1;
		notifyObservers(new GPMessageStateChanged(state, ""));
	}

	void validateCrossover(Program program, Program program1,
			Program aprogram[]) {
		for (int j = 0; j < aprogram.length; j++) {
			int i;
			if (aprogram[j] == null)
				i = 0;
			else
				i = maxDepthOfTree(aprogram[j]);
			if (i < 1 || i > maxDepthForIndividualsAfterCrossover.intValue()) {
				int k = random.nextInt(2);
				if (k == 0)
					aprogram[j] = (Program) program.clone();
				else
					aprogram[j] = (Program) program1.clone();
			}
		}

	}

	Terminal chooseFromTerminalSet() {
		Terminal terminal;
		try {
			int i = random.nextInt(terminalSet.countSelections());
			Class class1 = ((ProgramChoice) terminalSet.getSelectedItem(i))
					.value();
			terminal = (Terminal) class1.newInstance();
		} catch (Exception _ex) {
			terminal = null;
		}
		return terminal;
	}

	public synchronized void thaw() {
		if (thread != null && thread.isAlive()
				&& (oldState == 1 || oldState == 3))
			thread.resume();
	}

	String makeDefaultFitnessCases() {
		byte byte0 = 40;
//		String s = "// 3*x^4 - 3*x + 1\n";
		String s = "// sin(x)*sin(x) - 0.8 * cos(2 * 3.14 * x) * cos(2 * 3.14 * x) \n";
//		String s = "// ln(x) \n";
		for (int i = 0; i < byte0; i++) {
			double d = (double) i / (double) (byte0 - 1);
			if (d == 0.0D)
				d = 9.9999999999999995E-008D;
//			double d1 = 1.0D + -3D * d + 3D * d * d * d * d;
			double d1 = Math.sin(d) * Math.sin(d) - 0.8 * Math.cos(2 * Math.PI * d) * Math.cos(2 * Math.PI * d);
//			double d1 = Math.log(d);
			if (Math.abs(d) < 1.0000000000000001E-005D)
				d = 0.0D;
			if (Math.abs(d1) < 1.0000000000000001E-005D)
				d1 = 0.0D;
			s = s + d + "  " + d1 + "\n";
		}

		return s;
	}

	void normalizeFitnessOfPopulation() {
		double d = 0.0D;
		for (int i = 0; i < population.length; i++) {
			population[i].adjustedFitness = 1.0D / (population[i].standardizedFitness + 1.0D);
			d += population[i].adjustedFitness;
		}

		for (int j = 0; j < population.length; j++)
			population[j].normalizedFitness = population[j].adjustedFitness / d;

	}

	Program createIndividualProgram(int i, boolean flag, boolean flag1) {
		Object obj;
		if (i <= 0)
			obj = chooseFromTerminalSet();
		else if (flag1 || flag) {
			int j = random.nextInt(functionSet.countSelections());
			Function function;
			try {
				Class class1 = ((ProgramChoice) functionSet.getSelectedItem(j))
						.value();
				function = (Function) class1.newInstance();
			} catch (Exception _ex) {
				function = null;
			}
			createArgumentsForFunction(function, i - 1, flag1);
			obj = function;
		} else {
			int k = random.nextInt(terminalSet.countSelections()
					+ functionSet.countSelections());
			if (k < functionSet.countSelections()) {
				Function function1;
				try {
					Class class2 = ((ProgramChoice) functionSet
							.getSelectedItem(k)).value();
					function1 = (Function) class2.newInstance();
				} catch (Exception _ex) {
					function1 = null;
				}
				createArgumentsForFunction(function1, i - 1, flag1);
				obj = function1;
			} else {
				obj = chooseFromTerminalSet();
			}
		}
		return ((Program) (obj));
	}

	Individual findIndividual() {
		Individual individual = null;
		switch (((MethodOfSelection) methodOfSelection.getSelection())
				.getValue()) {
		case 1: // '\001'
			individual = findIndividualUsingTournamentSelection();
			break;

		case 0: // '\0'
			individual = findFitnessProportionateIndividual(random.nextDouble());
			break;
		}
		return individual;
	}

	Program mutate(Program program) {
		int i = random.nextInt(program.countNodes());
		Program program1 = createIndividualProgram(
				maxDepthForNewSubtreesInMutants.intValue(), true, false);
		Program program2 = (Program) program.clone();
		TreeHook treehook = getSubtree(program, i, isProgram);
		if (treehook.parent == null)
			program2 = treehook.subtree;
		else
			treehook.parent.arg[treehook.childIndex] = program1;
		return program2;
	}

	public synchronized void resume() {
		if (thread != null && thread.isAlive()) {
			thread.resume();
			state = 3;
			notifyObservers(new GPMessageStateChanged(state, ""));
		}
	}

	private void sort(int i, int j) {
		int k = i;
		int l = j;
		double d = population[(i + j) / 2].normalizedFitness;
		do {
			while (population[k].normalizedFitness > d)
				k++;
			for (; population[l].normalizedFitness < d; l--)
				;
			if (k <= l) {
				Individual individual = population[l];
				population[l] = population[k];
				population[k] = individual;
				k++;
				l--;
			}
		} while (k <= l);
		if (i < l)
			sort(i, l);
		if (k < j)
			sort(k, j);
	}

	Program[] crossover(Program program, Program program1) {
		double d = 0.90000000000000002D;
		Program aprogram[] = new Program[2];
		aprogram[0] = (Program) program.clone();
		aprogram[1] = (Program) program1.clone();
		boolean flag = random.nextDouble() < d;
		TreeHook treehook;
		if (flag) {
			int i = random.nextInt(program.countNodes(isFunction));
			treehook = getSubtree(aprogram[0], i, isFunction);
		} else {
			int j = random.nextInt(program.countNodes());
			treehook = getSubtree(aprogram[0], j, isProgram);
		}
		flag = random.nextDouble() < d;
		TreeHook treehook1;
		if (flag) {
			int k = random.nextInt(program1.countNodes(isFunction));
			treehook1 = getSubtree(aprogram[1], k, isFunction);
		} else {
			int l = random.nextInt(program1.countNodes());
			treehook1 = getSubtree(aprogram[1], l, isProgram);
		}
		if (treehook.parent == null)
			aprogram[0] = treehook1.subtree;
		else
			treehook.parent.arg[treehook.childIndex] = treehook1.subtree;
		if (treehook1.parent == null)
			aprogram[1] = treehook.subtree;
		else
			treehook1.parent.arg[treehook1.childIndex] = treehook.subtree;
		validateCrossover(program, program1, aprogram);
		return aprogram;
	}

	public synchronized void freeze() {
		oldState = getState();
		if (thread != null && thread.isAlive()
				&& (oldState == 1 || oldState == 3))
			thread.suspend();
	}

	public void settingsChanged() {
		notifyObservers(new GPMessageFitnessCasesSet(fitnessCases.get()));
	}

	void createPopulation() {
		Hashtable hashtable = new Hashtable();
		population = new Individual[populationSize.intValue()];
		int j = 1;
		boolean flag1 = false;
		int k = maxDepthForNewIndividuals.intValue();
		int l = 0;
		for (int i1 = 0; i1 < population.length;) {
			int i;
			boolean flag;
			switch (((MethodOfGeneration) methodOfGeneration.getSelection())
					.getValue()) {
			case 1: // '\001'
				i = k;
				flag = true;
				break;

			case 0: // '\0'
				i = k;
				flag = false;
				break;

			case 2: // '\002'
				i = j + i1 % ((k - j) + 1);
				if (l == 0 && i1 % ((k - j) + 1) == 0)
					flag1 = !flag1;
				flag = flag1;
				break;

			default:
				i = k;
				flag = false;
				break;
			}
			Program program = createIndividualProgram(i, true, flag);
			String s = program.toString(0);
			if (!hashtable.containsKey(s)) {
				population[i1] = new Individual(program);
				i1++;
				hashtable.put(s, program);
				l = 0;
			} else if (++l > 20) {
				j++;
				k = Math.max(k, j);
				l = 0;
			}
		}

	}

	void fitnessFunction(Individual individual, int i) {
		double d = 0.0D;
		individual.hits = 0;
		RealPoint arealpoint[] = new RealPoint[fitnessCases.get().length];
		for (int j = 0; j < fitnessCases.get().length; j++) {
			double d1 = fitnessCases.get()[j].x;
			double d2 = individual.program.eval(d1);
			double d3 = Math.abs(d2 - fitnessCases.get()[j].y);
			d += d3;
			if (d3 < 0.01D)
				individual.hits++;
			arealpoint[j] = new RealPoint(d1, d2);
		}

		individual.standardizedFitness = d;
		notifyObservers(new GPMessageEvaluatingIndividual(currentGeneration, i,
				arealpoint));
	}

	private TreeHook Walk(Program program, int ai[], Condition condition,
			Function function, int i) {
		if (condition.test(program) && ai[0] == 0)
			return new TreeHook(program, function, i);
		TreeHook treehook = null;
		if (program instanceof Function) {
			Function function1 = (Function) program;
			for (int j = 0; j < function1.arg.length && ai[0] > 0; j++) {
				if (condition.test(function1.arg[j]))
					ai[0]--;
				treehook = Walk(function1.arg[j], ai, condition, function1, j);
			}

		}
		return treehook;
	}

	public void run() {
		random.setSeed(12345L);
		notifyObservers(new GPMessageFitnessCasesSet(fitnessCases.get()));
		generationOfBestOfRunIndividual = 0;
		bestOfRunIndividual = null;
		createPopulation();
		currentGeneration = 0;
		while (!terminationPredicate())
			try {
				evolve();
				Thread.sleep(1L);
			} catch (Exception _ex) {
				crash();
			}
		stop();
	}

	public void init() {
		settingsChanged();
	}

	Individual findFitnessProportionateIndividual(double d) {
		double d1 = 0.0D;
		int j;
		for (j = 0; j < population.length && d1 < d; j++)
			d1 += population[j].normalizedFitness;

		int i;
		if (j >= population.length)
			i = population.length - 1;
		else
			i = j - 1;
		return population[i];
	}

	TreeHook getSubtree(Program program, int i, Condition condition) {
		int ai[] = { i };
		return Walk(program, ai, condition, null, -1);
	}

	void sortPopulationByFitness() {
		sort(0, population.length - 1);
	}

	void evolve() {
		if (currentGeneration > 0)
			breedNewPopulation();
		zeroizeFitnessMeasuresOfPopulation();
		evaluateFitnessOfPopulation();
		normalizeFitnessOfPopulation();
		sortPopulationByFitness();
		Individual individual = population[0];
		if (bestOfRunIndividual == null
				|| bestOfRunIndividual.standardizedFitness > individual.standardizedFitness) {
			bestOfRunIndividual = individual.copy();
			generationOfBestOfRunIndividual = currentGeneration;
			RealPoint arealpoint[] = new RealPoint[fitnessCases.get().length];
			for (int i = 0; i < fitnessCases.get().length; i++) {
				double d = fitnessCases.get()[i].x;
				double d1 = bestOfRunIndividual.program.eval(d);
				arealpoint[i] = new RealPoint(d, d1);
			}

			notifyObservers(new GPMessageBestFound(currentGeneration,
					bestOfRunIndividual.program.toString(0), arealpoint,
					bestOfRunIndividual.adjustedFitness));
		}
		double ad[] = new double[population.length];
		for (int j = 0; j < ad.length; j++)
			ad[j] = population[j].adjustedFitness;

		notifyObservers(new GPMessageEvaluatingPopulation(currentGeneration, ad));
		currentGeneration++;
	}

}