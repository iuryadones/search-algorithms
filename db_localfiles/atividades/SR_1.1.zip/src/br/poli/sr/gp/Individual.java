package br.poli.sr.gp;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
class Individual {

	Individual copy() {
		Individual individual = new Individual(program);
		individual.standardizedFitness = standardizedFitness;
		individual.adjustedFitness = adjustedFitness;
		individual.normalizedFitness = normalizedFitness;
		individual.hits = hits;
		return individual;
	}

	Individual(Program program1) {
		program = (Program) program1.clone();
		standardizedFitness = 0.0D;
		adjustedFitness = 0.0D;
		normalizedFitness = 0.0D;
		hits = 0;
	}

	public Program program;
	double standardizedFitness;
	double adjustedFitness;
	double normalizedFitness;
	int hits;
}