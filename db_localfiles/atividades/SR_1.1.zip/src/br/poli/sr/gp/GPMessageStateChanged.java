package br.poli.sr.gp;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
public class GPMessageStateChanged extends GPMessage {

	GPMessageStateChanged(int i, String s) {
		newState = i;
		text = s;
	}

	public int newState;
	public String text;
}