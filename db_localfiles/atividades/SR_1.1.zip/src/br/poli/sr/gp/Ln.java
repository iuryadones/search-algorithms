/**
 * 
 */
package br.poli.sr.gp;

/**
 * @author Danilo Ara�jo
 */
public class Ln extends Function {

	String getName() {
		return "ln";
	}

	double eval(double d) {
		double d1 = super.arg[0].eval(d);
		if (d1 > 100D)
			d1 = 100D;
		else if (d1 < -100D)
			d1 = -100D;
		return Math.log(d1);
	}

	Ln() {
		super.arg = new Program[1];
	}
}
