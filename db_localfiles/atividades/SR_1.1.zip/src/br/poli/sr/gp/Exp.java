package br.poli.sr.gp;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
class Exp extends Function {

	String getName() {
		return "exp";
	}

	double eval(double d) {
		double d1 = super.arg[0].eval(d);
		if (d1 > 100D)
			d1 = 100D;
		else if (d1 < -100D)
			d1 = -100D;
		return Math.exp(d1);
	}

	Exp() {
		super.arg = new Program[1];
	}
}