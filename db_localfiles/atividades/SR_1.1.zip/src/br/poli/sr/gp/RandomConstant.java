package br.poli.sr.gp;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
class RandomConstant extends Terminal {

	public String toString(int i) {
		return indent(i) + value;
	}

	RandomConstant() {
		value = GP.random.nextDouble() * 8D + -4D;
	}

	private RandomConstant(double d) {
		value = d;
	}

	String getName() {
		return "Random Constant";
	}

	protected Object clone() {
		return new RandomConstant(value);
	}

	double eval(double d) {
		return value;
	}

	static final double MIN = -4D;
	static final double MAX = 4D;
	double value;
}