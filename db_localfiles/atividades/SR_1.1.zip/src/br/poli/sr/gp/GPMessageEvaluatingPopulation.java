package br.poli.sr.gp;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
public class GPMessageEvaluatingPopulation extends GPMessage {

	GPMessageEvaluatingPopulation(int i, double ad[]) {
		generation = i;
		fitness = ad;
	}

	public int generation;
	public double fitness[];
}