/**
 * 
 */
package br.poli.sr.gp;

/**
 * @author Danilo Ara�jo
 */
public class Sqr extends Function {

	Sqr() {
		super.arg = new Program[1];
	}

	String getName() {
		return "^2";
	}

	double eval(double d) {
		double r = super.arg[0].eval(d);
		return r * r;
	}
}