package br.poli.sr.gp;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
class Division extends Function {

	Division() {
		super.arg = new Program[2];
	}

	String getName() {
		return "div";
	}

	double eval(double d) {
		double d1 = super.arg[1].eval(d);
		if (d1 == 0.0D)
			return 1.0D;
		else
			return super.arg[0].eval(d) / d1;
	}
}