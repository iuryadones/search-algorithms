package br.poli.sr.gp;

import br.poli.sr.ui.RealPoint;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
public class GPMessageBestFound extends GPMessage {

	GPMessageBestFound(int i, String s, RealPoint arealpoint[], double d) {
		generation = i;
		program = s;
		data = arealpoint;
		fitness = d;
	}

	public int generation;
	public String program;
	public RealPoint data[];
	public double fitness;
}