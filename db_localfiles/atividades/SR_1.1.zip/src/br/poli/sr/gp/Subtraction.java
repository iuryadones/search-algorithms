package br.poli.sr.gp;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
class Subtraction extends Function {

	String getName() {
		return "sub";
	}

	double eval(double d) {
		return super.arg[0].eval(d) - super.arg[1].eval(d);
	}

	Subtraction() {
		super.arg = new Program[2];
	}
}