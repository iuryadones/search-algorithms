/**
 * 
 */
package br.poli.sr.gp;

/**
 * @author Danilo Ara�jo
 */
public class Tan extends Function {

	Tan() {
		super.arg = new Program[1];
	}

	String getName() {
		return "tan";
	}

	double eval(double d) {
		return Math.tan(super.arg[0].eval(d));
	}
}