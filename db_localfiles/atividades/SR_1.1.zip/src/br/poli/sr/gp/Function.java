package br.poli.sr.gp;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
abstract class Function extends Program {

	public String toString(int i) {
		boolean flag = true;
		for (int j = 0; j < arg.length; j++)
			flag = flag && (arg[j] instanceof Terminal);

		String s = new String();
		if (!flag) {
			s = indent(i) + getName() + "(\n";
			int k;
			for (k = 0; k < arg.length - 1; k++)
				s = s + arg[k].toString(i + 1) + ",\n";

			if (k < arg.length)
				s = s + arg[k].toString(i + 1) + "\n";
			s = s + indent(i) + ")";
		} else {
			s = indent(i) + getName() + "(";
			int l;
			for (l = 0; l < arg.length - 1; l++)
				s = s + arg[l].toString(0) + ",";

			if (l < arg.length)
				s = s + arg[l].toString(0);
			s = s + ")";
		}
		return s;
	}

	int countNodes() {
		int i = 1;
		for (int j = 0; j < arg.length; j++)
			i += arg[j].countNodes();

		return i;
	}

	int countNodes(Condition condition) {
		int i = condition.test(this) ? 1 : 0;
		for (int j = 0; j < arg.length; j++)
			i += arg[j].countNodes(condition);

		return i;
	}

	Function() {
	}

	protected Object clone() {
		Function function = null;
		try {
			function = (Function) getClass().newInstance();
			for (int i = 0; i < arg.length; i++)
				function.arg[i] = (Program) arg[i].clone();

		} catch (Exception _ex) {
		}
		return function;
	}

	protected Program arg[];
}