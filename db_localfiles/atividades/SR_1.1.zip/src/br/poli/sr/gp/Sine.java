package br.poli.sr.gp;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
class Sine extends Function {

	Sine() {
		super.arg = new Program[1];
	}

	String getName() {
		return "sin";
	}

	double eval(double d) {
		return Math.sin(super.arg[0].eval(d));
	}
}