package br.poli.sr.ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
public class XYPlot extends Plot {
	final static float dash1[] = {10.0f};
	final static BasicStroke dashed = new BasicStroke(1.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, dash1, 0.0f);
	
	public synchronized void setTrace(int i, RealPoint arealpoint[]) {
		Graphics g = getGraphics();
		Dimension dimension = size();
		boolean flag = g != null && dimension.width != 0
				&& dimension.height != 0;
		if (flag) {
			setViewport();
			drawTrace(g, trace[i], getBackground());
		}
		trace[i] = arealpoint;
		if (flag)
			paint(g);
		if (g != null)
			g.dispose();
	}

	synchronized void drawTrace(Graphics g, RealPoint arealpoint[], Color color) {
		if (arealpoint != null) {
			int i = arealpoint.length;
			int ai[] = new int[i];
			int ai1[] = new int[i];
			for (int j = 0; j < i; j++) {
				ai[j] = xformX(arealpoint[j].x);
				ai1[j] = xformY(arealpoint[j].y);
			}

			g.setColor(color);
			for (int k = 0; k < i - 1; k++)
				g.drawLine(ai[k], ai1[k], ai[k + 1], ai1[k + 1]);

		}
	}

	public synchronized void paint(Graphics g) {
		Dimension dimension = size();
		if (previousSize == null || previousSize.width != dimension.width
				|| previousSize.height != dimension.height) {
			previousSize = dimension;
			update(g);
		}
		if (textWidth == 0) {
			FontMetrics fontmetrics = g.getFontMetrics();
			textWidth = fontmetrics.stringWidth("+1");
			textAscent = fontmetrics.getAscent();
		}
		Color color = getBackground();
		g.setColor(color);
		g.draw3DRect(0, 0, dimension.width - 1, dimension.height - 1, true);
		g.draw3DRect(3, 3, dimension.width - 7, dimension.height - 7, false);
		g.setColor(Color.black);
		g.clipRect(4, 4, dimension.width - 8, dimension.height - 8);
		setViewport();
		g.setColor(Color.gray);
		g.drawLine(xformX(super.xMin), xformY(0.0D), xformX(super.xMax),
				xformY(0.0D));
		g.drawLine(xformX(0.0D), xformY(super.yMax), xformX(0.0D),
				xformY(super.yMin));
		g.drawString("0", xformX(0.0D) - textWidth, xformY(0.0D) - 1);
		g.drawLine(xformX(1.0D), xformY(0.0D) - 3, xformX(1.0D),
				xformY(0.0D) + 3);
		g.drawString(" 1", xformX(1.0D) - textWidth / 2, xformY(0.0D) + 3
				+ textAscent);
		g.drawLine(xformX(0.0D) - 3, xformY(1.0D), xformX(0.0D) + 3,
				xformY(1.0D));
		g.drawString("+1", xformX(0.0D) - 3 - textWidth - 1, xformY(1.0D)
				+ textAscent / 2);
		g
				.drawLine(xformX(0.0D) - 3, xformY(-1D), xformX(0.0D) + 3,
						xformY(-1D));
		g.drawString("-1", xformX(0.0D) - 3 - textWidth - 1, xformY(-1D)
				+ textAscent / 2);
		drawTrace(g, trace[0], new Color(255, 0, 0));
		drawTrace(g, trace[1], new Color(0, 0, 255));
		((Graphics2D)g).setStroke(dashed);
		drawTrace(g, trace[2], new Color(0, 0, 0));
	}

	public XYPlot() {
		trace = new RealPoint[3][];
		setWindow(0.0D, -1.1000000000000001D, 1.05D, 1.1000000000000001D);
	}

	void setViewport() {
		Dimension dimension = size();
		super.setViewport(4 + textWidth + 3 + 3, 4, dimension.width - 4,
				dimension.height - 4);
	}

	RealPoint trace[][];
	Dimension previousSize;
	static final int FRAME_WIDTH = 4;
	int textWidth;
	int textAscent;
}