package br.poli.sr.ui;

import java.awt.Choice;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
public class ChoiceUI extends Choice implements Validatable {

	public void accept() {
		selection = getSelectedIndex();
	}

	public ChoiceUI(String s, Object aobj[], int i) {
		label = s;
		choices = aobj;
		selection = i;
		if (aobj != null) {
			for (int j = 0; j < aobj.length; j++)
				addItem(aobj[j].toString());

		}
		display();
	}

	public Object getSelection() {
		if (choices != null)
			return choices[selection];
		else
			return null;
	}

	public String check() {
		return null;
	}

	public void display() {
		select(selection);
	}

	public String getLabel() {
		return label;
	}

	private String label;
	private Object choices[];
	private int selection;
}