package br.poli.sr.ui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
public class Histogram extends Plot {
	private static final long serialVersionUID = 1L;

	public synchronized void paint(Graphics g) {
		Dimension dimension = getSize();
		g.setColor(getBackground());
		g.draw3DRect(0, 0, dimension.width - 1, dimension.height - 1, true);
		g.draw3DRect(3, 3, dimension.width - 7, dimension.height - 7, false);
		g.clipRect(4, 4, dimension.width - 8, dimension.height - 8);
		g.fillRect(4, 4, dimension.width - 8, dimension.height - 8);
		setViewport(4, 4, dimension.width - 4, dimension.height - 4);
		if (data != null) {
			g.setColor(Color.black);
			double d = 1.0D / (double) (data.length - 1);
			for (int i = 0; i < data.length; i++) {
				double d1 = (double) i / (double) data.length + d / 2D;
				double d2 = data[i];
				g.drawLine(xformX(d1), xformY(0.0D), xformX(d1), xformY(d2));
			}

		}
	}

	public Histogram() {
		setWindow(0.0D, 0.0D, 1.0D, 1.0D);
	}

	public void setData(double ad[]) {
		data = ad;
		paint(getGraphics());
	}

	private double data[];
}