package br.poli.sr.ui;

import java.awt.List;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
public class SetUI extends List implements Validatable {

	public SetUI(String s, Object aobj[], int ai[]) {
		super(0, true);
		label = s;
		choices = aobj;
		selections = ai;
		if (aobj != null) {
			for (int i = 0; i < aobj.length; i++)
				addItem(aobj[i].toString());

		}
		display();
	}

	public Object getSelectedItem(int i) {
		if (choices == null || selections == null)
			return null;
		else
			return choices[selections[i]];
	}

	public int countSelections() {
		if (selections == null)
			return 0;
		else
			return selections.length;
	}

	public void accept() {
		selections = getSelectedIndexes();
	}

	public String check() {
		if (getSelectedIndexes().length > 0)
			return null;
		else
			return "Em \"" + label + "\", no m�nimo um item precisa ser selecionado.";
	}

	public void display() {
		for (int i = 0; i < countItems(); i++)
			deselect(i);

		if (selections != null) {
			for (int j = 0; j < selections.length; j++)
				select(selections[j]);

		}
	}

	public String getLabel() {
		return label;
	}

	private String label;
	private Object choices[];
	private int selections[];
}