package br.poli.sr.ui;

import java.awt.Font;
import java.awt.TextArea;
import java.io.StreamTokenizer;
import java.io.StringBufferInputStream;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
public class PointsUI extends TextArea implements Validatable {

	public RealPoint[] get() {
		return data;
	}

	private RealPoint[] read(String s) {
		StringBufferInputStream stringbufferinputstream = new StringBufferInputStream(
				s);
		StreamTokenizer streamtokenizer = new StreamTokenizer(
				stringbufferinputstream);
		RealPoint arealpoint[] = new RealPoint[100];
		int i = 0;
		int j;
		try {
			do {
				j = streamtokenizer.nextToken();
				if (j == -2) {
					double d = streamtokenizer.nval;
					j = streamtokenizer.nextToken();
					if (j == -2) {
						double d1 = streamtokenizer.nval;
						arealpoint[i] = new RealPoint(d, d1);
						i++;
					}
				}
			} while (i < 100 && j != -1);
		} catch (Exception _ex) {
		}
		RealPoint arealpoint1[] = new RealPoint[i];
		System.arraycopy(arealpoint, 0, arealpoint1, 0, i);
		return arealpoint1;
	}

	public void accept() {
		rawText = getText();
		data = read(rawText);
	}

	public String check() {
		RealPoint arealpoint[] = read(getText());
		boolean flag = arealpoint != null && arealpoint.length >= 10;
		if (flag)
			return null;
		else
			return "\"" + label
					+ "\" precisa conter no m�nimo 10 pares de valores x-y.";
	}

	public void display() {
		setText(rawText);
	}

	public PointsUI(String s, String s1) {
		setFont(new Font("Courier", 0, 10));
		label = s;
		rawText = s1;
		data = read(s1);
		display();
	}

	public String getLabel() {
		return label;
	}

	private String label;
	private RealPoint data[];
	private String rawText;
	static final int MAX_NR_OF_FITNESS_CASES = 100;
}