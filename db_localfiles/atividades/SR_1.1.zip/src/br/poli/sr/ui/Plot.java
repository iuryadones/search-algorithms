package br.poli.sr.ui;

import java.awt.Canvas;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
public class Plot extends Canvas {

	public Plot() {
		xMin = -0.050000000000000003D;
		yMin = -1.05D;
		xMax = 1.05D;
		yMax = 1.05D;
		vRight = 100;
		vBottom = 100;
	}

	public int xformY(double d) {
		return (int) (((d - yMin) / (yMax - yMin)) * (double) (vTop - vBottom))
				+ vBottom;
	}

	public void setViewport(int i, int j, int k, int l) {
		vLeft = i;
		vTop = j;
		vRight = k;
		vBottom = l;
	}

	public void setWindow(double d, double d1, double d2, double d3) {
		xMin = d;
		xMax = d2;
		yMin = d1;
		yMax = d3;
	}

	public int xformX(double d) {
		return (int) (((d - xMin) / (xMax - xMin)) * (double) (vRight - vLeft))
				+ vLeft;
	}

	protected double xMin;
	protected double yMin;
	protected double xMax;
	protected double yMax;
	private int vLeft;
	private int vTop;
	private int vRight;
	private int vBottom;
}