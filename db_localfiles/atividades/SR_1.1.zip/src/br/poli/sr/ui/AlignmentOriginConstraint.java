package br.poli.sr.ui;

import java.awt.Dimension;
import java.awt.Rectangle;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
public class AlignmentOriginConstraint extends OriginConstraint {

	public Rectangle adjustedRectangle(Dimension dimension, Dimension dimension1) {
		Rectangle rectangle = super.adjustedRectangle(dimension, dimension1);
		rectangle.translate(-adjustedAlignmentLeft(dimension1),
				-adjustedAlignmentTop(dimension1));
		return rectangle;
	}

	protected int adjustedAlignmentTop(Dimension dimension) {
		return (int) Math.round(topAlignmentFraction
				* (double) dimension.height);
	}

	public AlignmentOriginConstraint() {
	}

	public AlignmentOriginConstraint(double d, int i, double d1, int j,
			double d2, double d3) {
		super(d, i, d1, j);
		leftAlignmentFraction = d2;
		topAlignmentFraction = d3;
	}

	protected int adjustedAlignmentLeft(Dimension dimension) {
		return (int) Math.round(leftAlignmentFraction
				* (double) dimension.width);
	}

	public Dimension containSize(Dimension dimension) {
		int i = super.left;
		int j = super.top;
		super.left -= adjustedAlignmentLeft(dimension);
		super.top -= adjustedAlignmentTop(dimension);
		Dimension dimension1 = super.containSize(dimension);
		super.left = i;
		super.top = j;
		return dimension1;
	}

	public double leftAlignmentFraction;
	public double topAlignmentFraction;
}