package br.poli.sr.ui;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
public interface Validatable {

	public abstract void accept();

	public abstract String check();

	public abstract void display();

	public abstract String getLabel();
}