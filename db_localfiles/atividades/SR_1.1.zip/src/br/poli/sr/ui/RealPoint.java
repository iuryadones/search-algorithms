package br.poli.sr.ui;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
public class RealPoint {

	public RealPoint(double d, double d1) {
		x = d;
		y = d1;
	}

	public double x;
	public double y;
}