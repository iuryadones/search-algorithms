package br.poli.sr.ui;

import java.awt.TextField;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
public class NumberUI extends TextField implements Validatable {

	private String label;
	private double value;
	private double min;
	private double max;

	public double doubleValue() {
		return value;
	}

	public int intValue() {
		return (int) value;
	}

	public double getMin() {
		return min;
	}

	public void accept() {
		double d;
		try {
			d = Double.valueOf(getText().trim()).doubleValue();
		} catch (NumberFormatException _ex) {
			d = 0.0D;
		}
		value = d;
	}

	public NumberUI(String s, double d, double d1, double d2) {
		label = s;
		min = d1;
		max = d2;
		value = d;
		display();
	}

	public double getMax() {
		return max;
	}

	public String check() {
		double d;
		boolean flag;
		try {
			d = Double.valueOf(getText().trim()).doubleValue();
			flag = true;
		} catch (NumberFormatException _ex) {
			d = 0.0D;
			flag = false;
		}
		flag = flag && d >= min && d <= max;
		if (flag)
			return null;
		else
			return "\"" + label + "\" precisa estar no intervalo " + min + " to "
					+ max + ".";
	}

	public void display() {
		setText("" + value);
	}

	public String getLabel() {
		return label;
	}
}