package br.poli.sr.ui;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.Rectangle;
import java.util.Hashtable;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
public class FractionalLayout implements LayoutManager {

	public Dimension minimumLayoutSize(Container container) {
		Insets insets = container.insets();
		int i = container.countComponents();
		Dimension dimension = new Dimension();
		for (int j = 0; j < i; j++) {
			Component component = container.getComponent(j);
			OriginConstraint originconstraint = getConstraint(component);
			Dimension dimension1 = originconstraint.containSize(component
					.minimumSize());
			dimension.width = Math.max(dimension.width, dimension1.width);
			dimension.height = Math.max(dimension.height, dimension1.height);
		}

		dimension.width += insets.left + insets.right;
		dimension.height += insets.top + insets.bottom;
		return dimension;
	}

	public void removeLayoutComponent(Component component) {
		components.remove(component);
	}

	public Dimension preferredLayoutSize(Container container) {
		Insets insets = container.insets();
		int i = container.countComponents();
		Dimension dimension = new Dimension();
		for (int j = 0; j < i; j++) {
			Component component = container.getComponent(j);
			OriginConstraint originconstraint = getConstraint(component);
			Dimension dimension1 = originconstraint.containSize(component
					.preferredSize());
			dimension.width = Math.max(dimension.width, dimension1.width);
			dimension.height = Math.max(dimension.height, dimension1.height);
		}

		dimension.width += insets.left + insets.right;
		dimension.height += insets.top + insets.bottom;
		return dimension;
	}

	public void layoutContainer(Container container) {
		Insets insets = container.insets();
		int i = container.countComponents();
		Dimension dimension = container.size();
		dimension.width -= insets.left + insets.right;
		dimension.height -= insets.top + insets.bottom;
		for (int j = 0; j < i; j++) {
			Component component = container.getComponent(j);
			OriginConstraint originconstraint = getConstraint(component);
			Rectangle rectangle = originconstraint.adjustedRectangle(dimension,
					component.preferredSize());
			component.reshape(rectangle.x, rectangle.y, rectangle.width,
					rectangle.height);
		}

	}

	public void addLayoutComponent(String s, Component component) {
		setConstraint(component, new OriginConstraint());
	}

	public FractionalLayout() {
		components = new Hashtable();
	}

	public void setConstraint(Component component,
			OriginConstraint originconstraint) {
		components.put(component, originconstraint);
	}

	public OriginConstraint getConstraint(Component component) {
		OriginConstraint originconstraint = (OriginConstraint) components
				.get(component);
		if (originconstraint == null) {
			originconstraint = new OriginConstraint();
			setConstraint(component, originconstraint);
		}
		return originconstraint;
	}

	protected Hashtable components;
}