package br.poli.sr.ui;

import java.awt.Dimension;
import java.awt.Rectangle;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
public class FrameConstraint extends OriginConstraint {

	protected int adjustedBottom(Dimension dimension) {
		return (int) Math.round(bottomFraction * (double) dimension.height)
				+ bottom;
	}

	public Rectangle adjustedRectangle(Dimension dimension, Dimension dimension1) {
		int i = adjustedLeft(dimension);
		int j = adjustedTop(dimension);
		int k = adjustedRight(dimension);
		int l = adjustedBottom(dimension);
		return new Rectangle(i, j, k - i, l - j);
	}

	public FrameConstraint() {
	}

	public FrameConstraint(double d, int i, double d1, int j, double d2, int k,
			double d3, int l) {
		super(d, i, d1, j);
		rightFraction = d2;
		right = k;
		bottomFraction = d3;
		bottom = l;
	}

	protected int adjustedRight(Dimension dimension) {
		return (int) Math.round(rightFraction * (double) dimension.width)
				+ right;
	}

	public Dimension containSize(Dimension dimension) {
		Dimension dimension1 = new Dimension();
		if (rightFraction != super.leftFraction)
			dimension1.width = (int) Math
					.ceil((double) ((dimension.width - right) + super.left)
							/ (rightFraction - super.leftFraction));
		else
			dimension1.width = (int) Math.ceil((double) Math.max(-super.left,
					-right)
					/ super.leftFraction);
		if (super.topFraction != bottomFraction)
			dimension1.height = (int) Math
					.ceil((double) ((dimension.height - bottom) + super.top)
							/ (bottomFraction - super.topFraction));
		else
			dimension1.height = (int) Math.ceil((double) Math.max(-super.top,
					-bottom)
					/ super.topFraction);
		return dimension1;
	}

	public double rightFraction;
	public int right;
	public double bottomFraction;
	public int bottom;
}