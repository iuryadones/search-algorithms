package br.poli.sr.ui;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Insets;
import java.awt.Label;
import java.awt.LayoutManager;
import java.awt.Rectangle;
import java.util.Hashtable;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
public class DialogLayout implements LayoutManager {

	public Dimension minimumLayoutSize(Container container) {
		return new Dimension(m_width, m_height);
	}

	public DialogLayout(Container container, int i, int j) {
		m_map = new Hashtable();
		Construct(container, i, j);
	}

	public DialogLayout(Container container, Dimension dimension) {
		m_map = new Hashtable();
		Construct(container, dimension.width, dimension.height);
	}

	public void setShape(Component component, int i, int j, int k, int l) {
		m_map.put(component, new Rectangle(i, j, k, l));
	}

	public void setShape(Component component, Rectangle rectangle) {
		m_map.put(component, new Rectangle(rectangle.x, rectangle.y,
				rectangle.width, rectangle.height));
	}

	public Rectangle getShape(Component component) {
		Rectangle rectangle = (Rectangle) m_map.get(component);
		return new Rectangle(rectangle.x, rectangle.y, rectangle.width,
				rectangle.height);
	}

	public Dimension getDialogSize() {
		return new Dimension(m_width, m_height);
	}

	public void removeLayoutComponent(Component component) {
	}

	protected void mapRectangle(Rectangle rectangle, int i, int j) {
		rectangle.x = (rectangle.x * i) / 4;
		rectangle.y = (rectangle.y * j) / 8;
		rectangle.width = (rectangle.width * i) / 4;
		rectangle.height = (rectangle.height * j) / 8;
	}

	public Dimension preferredLayoutSize(Container container) {
		return new Dimension(m_width, m_height);
	}

	protected int getCharHeight(Container container) {
		FontMetrics fontmetrics = container.getFontMetrics(container.getFont());
		int i = fontmetrics.getHeight();
		return i;
	}

	public void layoutContainer(Container container) {
		int i = container.countComponents();
		Rectangle rectangle = new Rectangle();
		int j = getCharHeight(container);
		int k = getCharWidth(container);
		Insets insets = container.insets();
		for (int l = 0; l < i; l++) {
			Component component = container.getComponent(l);
			Rectangle rectangle1 = (Rectangle) m_map.get(component);
			if (rectangle1 != null) {
				rectangle.x = rectangle1.x;
				rectangle.y = rectangle1.y;
				rectangle.height = rectangle1.height;
				rectangle.width = rectangle1.width;
				mapRectangle(rectangle, k, j);
				if (component instanceof Label) {
					rectangle.x -= 12;
					rectangle.width += 12;
				}
				rectangle.x += insets.left;
				rectangle.y += insets.top;
				component.reshape(rectangle.x, rectangle.y, rectangle.width,
						rectangle.height);
			}
		}

	}

	public void addLayoutComponent(String s, Component component) {
	}

	protected int getCharWidth(Container container) {
		FontMetrics fontmetrics = container.getFontMetrics(container.getFont());
		String s = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		int i = fontmetrics.stringWidth(s) / s.length();
		if (i <= 0)
			i = 1;
		return i;
	}

	protected void Construct(Container container, int i, int j) {
		Rectangle rectangle = new Rectangle(0, 0, i, j);
		mapRectangle(rectangle, getCharWidth(container),
				getCharHeight(container));
		m_width = rectangle.width;
		m_height = rectangle.height;
	}

	protected Hashtable m_map;
	protected int m_width;
	protected int m_height;
}