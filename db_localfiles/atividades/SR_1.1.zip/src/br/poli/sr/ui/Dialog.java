package br.poli.sr.ui;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.TextField;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
public class Dialog extends java.awt.Dialog {

	public Component addComponent(Component component, Rectangle rectangle) {
		Component component1 = super.add(component);
		layout.setShape(component, rectangle);
		return component1;
	}

	public void accept() {
		for (int i = 0; i < countComponents(); i++) {
			Component component = getComponent(i);
			if (component instanceof Validatable) {
				Validatable validatable = (Validatable) component;
				validatable.accept();
			}
		}

	}

	public String onApply() {
		String s = check();
		if (s == null) {
			accept();
			if (shouldBeModal)
				dispose();
		}
		return s;
	}

	public void show() {
		if (shouldBeModal)
			parent.disable();
		super.show();
	}

	public static Frame findFirstFrame(Component component) {
		Object obj;
		for (obj = component; obj != null; obj = ((Component) (obj))
				.getParent())
			if (obj instanceof Frame)
				break;

		return (Frame) obj;
	}

	public void dispose() {
		super.dispose();
		if (shouldBeModal)
			parent.enable();
	}

	public Dialog(Frame frame, Rectangle rectangle, String s, boolean flag) {
		super(frame, s, false);
		shouldBeModal = flag;
		parent = frame;
		Font font = getFont();
		if (font != null) {
			Font font1 = new Font(font.getName(), font.getStyle(), 8);
			setFont(font1);
		}
		layout = new DialogLayout(this, rectangle.width, rectangle.height);
		setLayout(layout);
		addNotify();
		Dimension dimension = layout.getDialogSize();
		Insets insets = insets();
		resize(insets.left + dimension.width + insets.right, insets.top
				+ dimension.height + insets.bottom);
		move(rectangle.x, rectangle.y);
	}

	public String check() {
		Object obj = null;
		for (int i = 0; i < countComponents(); i++) {
			Component component = getComponent(i);
			if (component instanceof Validatable) {
				String s = ((Validatable) component).check();
				if (s != null) {
					component.requestFocus();
					if (component instanceof TextField)
						((TextField) component).selectAll();
					return s;
				}
			}
		}

		return null;
	}

	public boolean handleEvent(Event event) {
		switch (event.id) {
		case 201: // Event.WINDOW_DESTROY
			onCancel();
			return true;
		}
		return super.handleEvent(event);
	}

	public void onCancel() {
		dispose();
	}

	protected Frame parent;
	protected DialogLayout layout;
	private boolean shouldBeModal;
}