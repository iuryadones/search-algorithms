package br.poli.sr.ui;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.util.Hashtable;

/**
 * Este programa foi adaptado a partir do miniaplcativo java (applet) dispon�vel em http://alphard.ethz.ch/gerber/approx/default.html.
 * John R. Koza � o autor original dos algoritmos usados nesse software.
 * 
 * @author Danilo Ara�jo
 */
public class StackLayout implements LayoutManager {

	int countDigits(String s, int i) {
		int k = s.length();
		int j;
		for (j = i; j < k && Character.isDigit(s.charAt(j)); j++)
			;
		return j - i;
	}

	public Dimension minimumLayoutSize(Container container) {
		return computeLayoutSize(container, false);
	}

	int parseArg(String s, int i, int j) {
		int k = -1;
		try {
			k = Integer.parseInt(s.substring(i, i + j));
		} catch (Exception _ex) {
		}
		return k;
	}

	boolean stretches(Component component) {
		int ai[] = getCode(component);
		return ai[orientation] == 4;
	}

	Dimension computeLayoutSize(Container container, boolean flag) {
		Insets insets = container.insets();
		int i = insets.left + insets.right;
		int j = insets.top + insets.bottom;
		int k = container.countComponents();
		if (orientation == 0) {
			int l = 0;
			int j1 = 0;
			for (int j2 = 0; j2 < k; j2++) {
				Component component = container.getComponent(j2);
				if (component.isVisible()) {
					int l2 = getCode(component)[orientation];
					int l1 = (l2 & 0x10) != 0 ? 0 : margin;
					Dimension dimension = !flag || (l2 & 0xc) != 4 ? component
							.minimumSize() : component.preferredSize();
					l = Math.max(l, dimension.height + 2 * l1);
					j1 += dimension.width + 2 * l1;
				}
			}

			return new Dimension(j1 + i, l + j);
		}
		int i1 = 0;
		int k1 = 0;
		for (int k2 = 0; k2 < k; k2++) {
			Component component1 = container.getComponent(k2);
			if (component1.isVisible()) {
				int i3 = getCode(component1)[orientation];
				int i2 = (i3 & 0x10) != 0 ? 0 : margin;
				Dimension dimension1 = !flag || (i3 & 0xc) != 4 ? component1
						.minimumSize() : component1.preferredSize();
				i1 = Math.max(i1, dimension1.width + 2 * i2);
				k1 += dimension1.height + 2 * i2;
			}
		}

		return new Dimension(i1 + i, k1 + j);
	}

	public void removeLayoutComponent(Component component) {
		codeTable.remove(component);
	}

	public Dimension preferredLayoutSize(Container container) {
		return computeLayoutSize(container, true);
	}

	public void layoutContainer(Container container) {
		int i = orientation;
		int j = (orientation + 1) % 2;
		int k = container.countComponents();
		Insets insets = container.insets();
		Dimension dimension = container.size();
		int l = dimension.width - insets.left - insets.right;
		int i1 = dimension.height - insets.top - insets.bottom;
		int j1 = orientation != 0 ? i1 : l;
		int k1 = orientation != 0 ? l : i1;
		int l1 = 0;
		int i2 = 0;
		int j2 = 0;
		int k2 = 1;
		int ai[][] = new int[k][];
		int ai1[][] = new int[k][2];
		for (int l2 = 0; l2 < k; l2++) {
			Component component = container.getComponent(l2);
			if (component.isVisible()) {
				Dimension dimension1 = component.minimumSize();
				int ai2[] = getCode(component);
				int ai3[] = ai1[l2];
				ai[l2] = ai2;
				ai3[0] = dimension1.width;
				ai3[1] = dimension1.height;
				int j4 = ai3[i];
				int l4 = ai2[i];
				switch (l4 & 0xc) {
				case 4: // '\004'
					l1 += ai2[i + 2];
					break;

				case 8: // '\b'
					j2 += ai2[i + 2];
					break;

				case 5: // '\005'
				case 6: // '\006'
				case 7: // '\007'
				default:
					j2 += j4;
					break;
				}
				switch (l4 & 3) {
				case 0: // '\0'
					i2++;
					break;

				case 2: // '\002'
					if (k2 != 2)
						i2++;
					break;
				}
				if ((l4 & 0x10) == 0)
					j2 += 2 * margin;
				k2 = l4 & 3;
			}
		}

		if (k2 == 0)
			i2++;
		int i3 = l1 == 0 && i2 != 0 ? Math.max(0, (j1 - j2) / i2) : 0;
		int j3 = l1 != 0 ? Math.max(0, (j1 - j2) / l1) : 0;
		int k3 = orientation != 0 ? insets.top : insets.left;
		int l3 = orientation != 0 ? insets.left : insets.top;
		k2 = 1;
		for (int k5 = 0; k5 < k; k5++) {
			int ai4[] = ai[k5];
			int ai5[] = ai1[k5];
			if (ai4 != null) {
				int l5 = ai4[i];
				int i6 = ai4[j];
				int j5 = (l5 & 0x10) != 0 ? 0 : margin;
				k3 += j5;
				int i4 = l3 + j5;
				int k4 = ai5[i];
				int i5 = ai5[j];
				switch (l5 & 0xc) {
				case 4: // '\004'
					if (j3 > 0)
						k4 = j3 * ai4[i + 2];
					break;

				case 8: // '\b'
					k4 = ai4[i + 2];
					break;
				}
				switch (l5 & 3) {
				case 1: // '\001'
				default:
					break;

				case 0: // '\0'
					k3 += i3;
					break;

				case 2: // '\002'
					if (k2 != 2)
						k3 += i3;
					break;
				}
				k2 = l5 & 3;
				switch (i6 & 0xc) {
				case 4: // '\004'
					i5 = k1 - 2 * j5;
					break;

				case 8: // '\b'
					i5 = ai4[j + 2];
					break;
				}
				switch (i6 & 3) {
				case 2: // '\002'
					i4 += k1 - i5;
					break;

				case 0: // '\0'
					i4 += (k1 - i5) / 2;
					break;
				}
				Component component1 = container.getComponent(k5);
				if (orientation == 0)
					component1.reshape(k3, i4, k4, i5);
				else
					component1.reshape(i4, k3, i5, k4);
				k3 += k4 + j5;
			}
		}

	}

	public void addLayoutComponent(String s, Component component) {
		s = s.toUpperCase().trim();
		int i = 0;
		int j = 0;
		int k = 0;
		int l = 0;
		int j1 = s.length();
		for (int i1 = 0; i1 < j1;) {
			if (!s.startsWith("CENTER", i1))
				if (s.startsWith("LEFT", i1)) {
					i1 += 4;
					i |= 1;
				} else if (s.startsWith("TOP", i1)) {
					i1 += 3;
					j |= 1;
				} else if (s.startsWith("RIGHT", i1)) {
					i1 += 5;
					i |= 2;
				} else if (s.startsWith("BOTTOM", i1)) {
					i1 += 6;
					j |= 2;
				} else if (s.startsWith("WIDE", i1)) {
					i1 += 4;
					i |= 4;
					if (s.startsWith("*", i1)) {
						i1++;
						int k1 = countDigits(s, i1);
						k = parseArg(s, i1, k1);
						i1 += k1;
					} else {
						k = 1;
					}
				} else if (s.startsWith("TALL", i1)) {
					i1 += 4;
					j |= 4;
					if (s.startsWith("*", i1)) {
						i1++;
						int l1 = countDigits(s, i1);
						l = parseArg(s, i1, l1);
						i1 += l1;
					} else {
						l = 1;
					}
				} else if (s.startsWith("FILL", i1)) {
					i1 += 4;
					i |= 4;
					j |= 4;
					if (s.startsWith("*", i1)) {
						i1++;
						int i2 = countDigits(s, i1);
						k = l = parseArg(s, i1, i2);
						i1 += i2;
					} else {
						k = l = 1;
					}
				} else if (s.startsWith("WIDTH", i1)) {
					i1 += 5;
					i |= 8;
					if (s.startsWith("=", i1)) {
						i1++;
						int j2 = countDigits(s, i1);
						k = parseArg(s, i1, j2);
						i1 += j2;
					} else {
						k = -1;
						break;
					}
				} else if (s.startsWith("HEIGHT", i1)) {
					i1 += 6;
					j |= 8;
					if (s.startsWith("=", i1)) {
						i1++;
						int k2 = countDigits(s, i1);
						l = parseArg(s, i1, k2);
						i1 += k2;
					} else {
						l = -1;
						break;
					}
				} else if (s.startsWith("FLUSH", i1)) {
					i1 += 5;
					i |= 0x10;
					j |= 0x10;
				} else {
					k = -1;
					break;
				}
			for (i1 += 6; i1 < j1 && Character.isSpace(s.charAt(i1)); i1++)
				;
		}

		if (k == -1 || l == -1) {
			System.out.println("StackLayout: can't understand \"" + s + "\"");
			return;
		} else {
			int ai[] = { i, j, k, l };
			codeTable.put(component, ai);
			return;
		}
	}

	public StackLayout() {
		margin = 2;
		codeTable = new Hashtable();
	}

	public StackLayout(int i) {
		margin = 2;
		codeTable = new Hashtable();
		orientation = i;
	}

	public StackLayout(int i, int j) {
		margin = 2;
		codeTable = new Hashtable();
		orientation = i;
		margin = j;
	}

	int[] getCode(Component component) {
		int ai[] = (int[]) codeTable.get(component);
		if (ai == null)
			return defaultCode;
		else
			return ai;
	}

	public static final int HORIZONTAL = 0;
	public static final int VERTICAL = 1;
	int orientation;
	int margin;
	Hashtable codeTable;
	static final int CENTER = 0;
	static final int FRONT = 1;
	static final int BACK = 2;
	static final int FILL = 4;
	static final int ABS = 8;
	static final int FLUSH = 16;
	static final int POSMASK = 3;
	static final int SIZEMASK = 12;
	int defaultCode[] = { 0, 0, 0, 0 };
}